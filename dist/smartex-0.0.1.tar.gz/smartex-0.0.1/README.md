# smartex

[![PyPI - Version](https://img.shields.io/pypi/v/smartex.svg)](https://pypi.org/project/smartex)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/smartex.svg)](https://pypi.org/project/smartex)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install smartex
```

## License

`smartex` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
